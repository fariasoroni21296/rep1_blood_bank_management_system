  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Made by Faria Soroni</p>
        </div>
        <!-- /.container -->
    </footer>